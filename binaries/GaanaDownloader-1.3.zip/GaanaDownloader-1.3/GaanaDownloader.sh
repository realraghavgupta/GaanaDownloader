#!/bin/bash
java -jar ${0%/*}/GaanaDownloader.jar "$@"